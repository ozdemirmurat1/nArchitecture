﻿namespace Application.Features.OperationClaims.Constants;

public static class GeneralOperationClaims
{
    public const string Admin = "Admin";
}
