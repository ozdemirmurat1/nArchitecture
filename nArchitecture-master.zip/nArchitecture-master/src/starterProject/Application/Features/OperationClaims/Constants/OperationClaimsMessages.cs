namespace Application.Features.OperationClaims.Constants;

public static class OperationClaimsMessages
{
    public const string NotExists = "Operation Claim not exists.";
    public const string AlreadyExists = "Operation Claim already exists.";
}
